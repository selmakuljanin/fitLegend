package com.example.fitlegend;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

// DAO should be interface
@Dao
public interface UserDAO {

    @Insert
    void registerUser(UserEntity userEntity);

    @Query("SELECT * from users where username=(:username) and password=(:password)")
    UserEntity login(String username, String password);


}
