package com.example.fitlegend;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class HomeScreen extends AppCompatActivity {

    TextView Name;
    private ListView listView;

    private Button button10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        Name = findViewById(R.id.name);
        String name = getIntent().getStringExtra("name");
        Name.setText(name);




    }


    public void bmi(View view) {
        startActivity(new Intent(HomeScreen.this, BMIActivity.class));
    }

    public void bmr(View view) {
        startActivity(new Intent(HomeScreen.this, BMRActivity.class));
    }

    public void journal(View view) {
        startActivity(new Intent(HomeScreen.this, JournalActivity.class));
    }

    public void workouts(View view) {
        startActivity(new Intent(HomeScreen.this, WorkoutActivity.class));
    }
}