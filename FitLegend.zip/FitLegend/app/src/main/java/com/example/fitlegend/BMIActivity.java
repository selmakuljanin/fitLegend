package com.example.fitlegend;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class BMIActivity extends AppCompatActivity {

    private EditText bmi_weight;
    private EditText bmi_height;
    private Button bmi_button;
    private TextView bmi_result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmiactivity);

        bmi_weight = (EditText) findViewById(R.id.bmi_weight);
        bmi_height = (EditText) findViewById(R.id.bmi_height);
        bmi_button = (Button) findViewById(R.id.bmi_button);
        bmi_result = (TextView) findViewById(R.id.bmi_result);

        bmi_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int number1 = Integer.parseInt(bmi_weight.getText().toString());
                int number2 = Integer.parseInt(bmi_height.getText().toString());
                int result = (100*100*number1)/(number2*number2);
                bmi_result.setText(String.valueOf(result));
            }
        });

    }
}