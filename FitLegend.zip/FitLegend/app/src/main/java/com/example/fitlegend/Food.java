package com.example.fitlegend;

import java.util.Date;

// we made a food entity to store different foods in the food journal and reuse themlater,however, we could not implement that properly


public class Food {

    private String foodName;

    private Integer calorieNumber;

    private Date entryDate;

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }


    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public Integer getCalorieNumber() {
        return calorieNumber;
    }

    public void setCalorieNumber(Integer calorieNumber) {
        this.calorieNumber = calorieNumber;
    }
}
