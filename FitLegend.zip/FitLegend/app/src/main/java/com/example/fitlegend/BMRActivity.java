package com.example.fitlegend;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class BMRActivity extends AppCompatActivity {

    private EditText bmr_weight;
    private EditText bmr_height;
    private EditText bmr_age;
    private Button bmr_button;
    private TextView bmr_result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmractivity);

        bmr_weight = (EditText) findViewById(R.id.bmr_weight);
        bmr_height = (EditText) findViewById(R.id.bmr_height);
        bmr_age = (EditText) findViewById(R.id.bmr_age);
        bmr_button = (Button) findViewById(R.id.bmr_button);
        bmr_result = (TextView) findViewById(R.id.bmr_result);

        bmr_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num1 = Integer.parseInt(bmr_weight.getText().toString());
                int num2 = Integer.parseInt(bmr_height.getText().toString());
                int num3 = Integer.parseInt(bmr_age.getText().toString());
                double calories = 88.362 + (13.397 + num1) + (4.799*num2) - (5.677*num3);
                bmr_result.setText(String.valueOf(calories));
    }
});

    ;

}
}