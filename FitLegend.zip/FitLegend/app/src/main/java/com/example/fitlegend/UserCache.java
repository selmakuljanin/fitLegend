package com.example.fitlegend;

public class UserCache {

    private static final UserCache instance = new UserCache();

    UserEntity currentUser = null;

    public static UserCache getInstance() {
        return instance;

    }

    public UserEntity getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(UserEntity currentUser) {
        this.currentUser = currentUser;
    }

    public void clearUser() {
        setCurrentUser(null);
    }
}

//we tried to make a user cache with one instance in order to connect it with the calorie goal and for it to be specific to a user, even if it were to be updated, and then display it on the home page, however we did not have the time to properly explore and implement this feature
