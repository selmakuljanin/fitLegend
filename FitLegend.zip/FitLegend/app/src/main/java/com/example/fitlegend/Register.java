package com.example.fitlegend;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.app.NotificationManager;
import android.app.NotificationChannel;
import android.graphics.Color;

public class Register extends AppCompatActivity {

    EditText username, password, name;
    Button register;
    Button login;
    private NotificationManager notifyManager;
    private static final String CHANNEL_ID = "notification_channel";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        name = findViewById(R.id.name);
        register = findViewById(R.id.register);
        login = findViewById(R.id.login);

        UserCache.getInstance().setCurrentUser(null);

        createNotificationChannel();
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Creating the User entity
                UserEntity userEntity = new UserEntity();
                userEntity.setUsername(username.getText().toString());
                userEntity.setPassword(password.getText().toString());
                userEntity.setName(name.getText().toString());
                if (validateInput(userEntity)) {
                    // initializing the user database
                    UserDatabase userDatabase = UserDatabase.getUserDatabase(getApplicationContext());
                    // initializing the user DAO
                    UserDAO userDAO = userDatabase.userDAO();
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            //calling the register method
                            userDAO.registerUser(userEntity);
                            //in the beginning, the toast would not show up and would crash the app, so we made a new runnable
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getApplicationContext(), "User successfully registered", Toast.LENGTH_SHORT).show();

                                    sendNotification("register", "registered!");
                                }
                            });

                        }
                    }).start();
                } else {
                    Toast.makeText(getApplicationContext(), "All fields are required", Toast.LENGTH_SHORT).show();
                }
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Register.this, Login.class));

            }
        });
    }

    // error message if not all fields have input for the registration
    private Boolean validateInput(UserEntity userEntity) {
        if(userEntity.getUsername().isEmpty()||
                userEntity.getPassword().isEmpty() ||
                userEntity.getName().isEmpty()) {
            return false;
        }
        return true;
    }

    public void login(View view) {
        startActivity(new Intent(Register.this, Login.class));

    }

    public void homescreen(View view) {
        startActivity(new Intent(Register.this, HomeScreen.class));;
    }
    public void sendNotification(String title, String text){
        NotificationCompat.Builder notifyBuilder = getNotificationBuilder(title, text);
        notifyManager.notify(1, notifyBuilder.build());
    }
    private NotificationCompat.Builder getNotificationBuilder(String title, String text){
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingNotificationIntent = PendingIntent.getActivity(this, 1,
                notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder notifyBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.trophy)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true);

        return notifyBuilder;
    }
    public void createNotificationChannel(){
        notifyManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID,
                    "My notification", NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.BLUE);
            notificationChannel.enableVibration(true);
            notificationChannel.setDescription("This is my notification!");

            notifyManager.createNotificationChannel(notificationChannel);
        }



    }
}

