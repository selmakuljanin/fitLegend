package com.example.fitlegend;

public class Menu {

    private String menu_option;
    private int imageResId;

    public Menu(String menu_option, int imageResId) {
        this.menu_option = menu_option;
        this.imageResId = imageResId;
    }

    public String getMenu_option() {
        return menu_option;
    }

    public void setMenu_option(String menu_option) {
        this.menu_option = menu_option;
    }

    public int getImageResId() {
        return imageResId;
    }

    public void setImageResId(int imageResId) {
        this.imageResId = imageResId;
    }
}
