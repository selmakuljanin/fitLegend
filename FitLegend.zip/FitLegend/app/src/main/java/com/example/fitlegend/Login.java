package com.example.fitlegend;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    EditText username, password;
    Button login;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        login = findViewById(R.id.login);

        UserCache.getInstance().setCurrentUser(null);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //error message if not all fields have input for the login
                final String usernameText = username.getText().toString();
                final String passwordText = password.getText().toString();
                if (usernameText.isEmpty() || passwordText.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "All fields are required", Toast.LENGTH_SHORT).show();
                } else {
                    // initializing the db
                    UserDatabase userDatabase = UserDatabase.getUserDatabase(getApplicationContext());
                    // initializing the DAO
                    final UserDAO userDAO = userDatabase.userDAO();
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            UserEntity userEntity = userDAO.login(usernameText, passwordText);
                            if (userEntity == null) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(getApplicationContext(), "Invalid username or password", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            } else {

                                // setting current user into cache

                                UserCache.getInstance().setCurrentUser(userEntity);

                                // putting the user's name on the homescreen

                                String name = userEntity.name;
                                startActivity(new Intent(Login.this, HomeScreen.class)
                                                .putExtra("name", name));
                            }
                        }
                    }).start();;


            }
        }
        })
;}

    public void register(View view) {

        startActivity(new Intent(Login.this, Register.class));
    }

    public void homescreen(View view) {
        startActivity(new Intent(Login.this, HomeScreen.class));
    }
}